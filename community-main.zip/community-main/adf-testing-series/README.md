# ADF testing series

Demo code to accompany [my series of posts](https://richardswinbank.net/adf/set_up_automated_testing_for_azure_data_factory) on automated testing for Azure Data Factory pipelines.
