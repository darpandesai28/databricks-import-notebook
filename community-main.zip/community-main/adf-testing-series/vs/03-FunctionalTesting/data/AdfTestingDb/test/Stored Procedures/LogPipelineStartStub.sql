﻿CREATE PROC [test].[LogPipelineStartStub] (
  @pipelineName NVARCHAR(255)
)
AS
 
SELECT -17483 AS RunId;