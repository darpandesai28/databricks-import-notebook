﻿CREATE TABLE [test].[TenTitleStub] (
    [title_id] CHAR (6) NOT NULL,
    CONSTRAINT [PK__test_TenTitleStub] PRIMARY KEY CLUSTERED ([title_id] ASC)
);

