﻿CREATE TABLE [test].[HundredTitleStub] (
    [title_id] CHAR (6) NOT NULL,
    CONSTRAINT [PK__test_HundredTitleStub] PRIMARY KEY CLUSTERED ([title_id] ASC)
);

