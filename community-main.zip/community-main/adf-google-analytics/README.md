# Extracting Google Analytics data using Azure Data Factory

The contents of this folder relate to my [post(s)](https://richardswinbank.net/adf/access_google_analytics_with_azure_data_factory) on using ADF to extract data from Google Analytics.
