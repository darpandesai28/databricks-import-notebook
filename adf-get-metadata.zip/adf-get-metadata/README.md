# Get metadata recursively

The code in this folder accompanies my [blog posts](https://richardswinbank.net/adf/get_more_metadata) about getting metadata recursively in Azure Data Factory.

* `Path` contains the example file tree 
* `vs` contains the Azure Function definition
* `adf` contains the ADF pipeline definition. This is for interest only - its performance is **terrible**!
