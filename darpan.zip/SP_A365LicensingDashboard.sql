/*
IF object_id('tempdb.dbo.#A365LicensingDashboard_dd') is not null
drop table #A365LicensingDashboard_dd

Create table #A365LicensingDashboard_dd
(
Id int Identity,
ReportDate varchar(50),
ReportFullDate date,
ReportPeriod varchar(25),
NumberOfDays int,
TotalLogIn int)

Insert into #A365LicensingDashboard_dd
(
ReportDate,
ReportFullDate,
ReportPeriod,
NumberOfDays,
TotalLogIn)
select '1-Oct-'+ RIGHT(cast(year(getdate()) as varchar(4)),2),cast(year(getdate()) as varchar(4)) + '-10-01','Sep',30,29
UNION
select '1-Nov-'+ RIGHT(cast(year(getdate()) as varchar(4)),2),cast(year(getdate()) as varchar(4)) + '-11-01','Oct',31,29
UNION
select '1-Dec-'+ RIGHT(cast(year(getdate()) as varchar(4)),2),cast(year(getdate()) as varchar(4)) + '-12-01','Nov',30,29
UNION
select '1-Jan-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-01-01','Nov - Dec',61,58
UNION
select '1-Feb-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-02-01','Nov - Jan',92,87
UNION
select '1-Mar-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-03-01','Nov - Feb',120,116
UNION
select '1-Apr-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-04-01','Nov - Mar',151,146
UNION
select '1-May-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-05-01','Nov - Apr',181,175
UNION
select '1-Jun-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-06-01','Nov - May',212,204
UNION
select '1-Jul-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-07-01','Nov - Jun',242,233
UNION
select '1-Aug-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-08-01','Nov - Jul',273,262
UNION
select '1-Sep-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-09-01','Nov - Aug',304,291
UNION
select '1-Oct-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-10-01','Nov - Sep',334,321
UNION
select '1-Nov-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-11-01','Nov - Oct',365,350

--Select * from #A365LicensingDashboard_dd
*/
IF object_id('tempdb.dbo.#DriverTable') is not null
drop table #DriverTable

Select * into #DriverTable
from #A365LicensingDashboard_dd
where Id <= (Select Id from #A365LicensingDashboard_dd 
                       where substring(ReportDate,3,3) = Left(datename(month,getdate()),3)
					     and substring(ReportDate,7,2) = RIGHT(cast(year(getdate()) as varchar(4)),2))

declare @ReportDate varchar(50)
declare @ReportPeriod varchar(25)
declare @lastActivityDate date
declare @NumberOfDays int 
declare @TotalLogIn int 
declare @Counter int
declare @MaxCounter int

IF object_id('tempdb.dbo.#A365LicensingDashboard') is not null
drop table #A365LicensingDashboard

Create table #A365LicensingDashboard
(
ReportDate varchar(50),
ReportPeriod varchar(25),
NumberOfDays int,
TotalLogIn int,
[< Login #] int,
[> Login #] int
)

SET @Counter = (Select Top 1 Id from #DriverTable order by Id)
SET @MaxCounter = (Select Max(Id) from #DriverTable)

While (@Counter <= @MaxCounter)

Begin
Select @ReportDate   = ReportDate,
       @lastActivityDate = ReportFullDate,
       @ReportPeriod = ReportPeriod,
       @NumberOfDays = NumberOfDays,
       @TotalLogIn   = TotalLogIn 
       from #DriverTable where Id = @Counter
select @ReportDate, @ReportPeriod, @lastActivityDate, @NumberOfDays, @TotalLogIn

--emailActivity
IF object_id('tempdb.dbo.#emailActivity') is not null
drop table #emailActivity

Declare @emailActivity_reportRefreshDate date
SET @emailActivity_reportRefreshDate = (select Max(reportRefreshDate) from [a365].[emailActivity])

SELECT [userKey]
      ,[Count of Activity] = COUNT(Distinct lastActivityDate)
into #emailActivity 
FROM [a365].[emailActivity]
WHERE lastActivityDate between dateadd(day,-@NumberOfDays,@lastActivityDate) and @lastActivityDate
group by [userKey]

--onedriveActivity
IF object_id('tempdb.dbo.#onedriveActivity') is not null
drop table #onedriveActivity

Declare @onedriveActivity_reportRefreshDate date
SET @onedriveActivity_reportRefreshDate = (select Max(reportRefreshDate) from [a365].[onedriveActivity])

SELECT [userKey]
      ,[Count of Activity] = COUNT(Distinct lastActivityDate)
into #onedriveActivity
FROM [a365].[onedriveActivity]
WHERE lastActivityDate between dateadd(day,-@NumberOfDays,@lastActivityDate) and @lastActivityDate
group by [userKey]

--sharepointActivity
IF object_id('tempdb.dbo.#sharepointActivity') is not null
drop table #sharepointActivity

Declare @sharepointActivity_reportRefreshDate date
SET @sharepointActivity_reportRefreshDate = (select Max(reportRefreshDate) from [a365].[sharepointActivity])

SELECT [userKey]
      ,[Count of Activity] = COUNT(Distinct lastActivityDate)
into #sharepointActivity
FROM [a365].[sharepointActivity]
WHERE lastActivityDate between dateadd(day,-@NumberOfDays,@lastActivityDate) and @lastActivityDate
group by [userKey]

--teamsActivity
IF object_id('tempdb.dbo.#teamsActivity') is not null
drop table #teamsActivity

Declare @teamsActivity_reportRefreshDate date
SET @teamsActivity_reportRefreshDate = (select Max(reportRefreshDate) from [a365].[teamsActivity])

SELECT [userKey]
      ,[Count of Activity] = COUNT(Distinct lastActivityDate)
into #teamsActivity
FROM [a365].[teamsActivity]
WHERE lastActivityDate between dateadd(day,-@NumberOfDays,@lastActivityDate) and @lastActivityDate
group by [userKey]


IF object_id('tempdb.dbo.#userActivity') is not null
drop table #userActivity

select [userKey]
      ,[Count of Activity] = sum([Count of Activity])
into #userActivity
from (select * from #emailActivity ea
	  UNION ALL
	  select * from #onedriveActivity oa
	  UNION ALL
	  select * from #sharepointActivity sa
	  UNION ALL
	  select * from #teamsActivity ta) as x
Group by [userKey]

INSERT INTO #A365LicensingDashboard (ReportDate,ReportPeriod,NumberOfDays,TotalLogIn,[< Login #],[> Login #])
Select @ReportDate as ReportDate,
       @ReportPeriod as ReportPeriod,
	   @NumberOfDays as NumberOfDays,
	   @TotalLogIn as TotalLogIn,
       sum(case when [Count of Activity] < @TotalLogIn then 1 else 0 end) as [< Login #],
	   sum(case when [Count of Activity] > @TotalLogIn then 1 else 0 end) as [> Login #]
from #userActivity

--Delete Processed Loop
Delete from #DriverTable where Id = @Counter
--Setting New Loop
SET @Counter = (Select Top 1 Id from #DriverTable order by Id)

end 

select ISNULL(a.ReportDate,b.ReportDate) as ReportDate,
	   ISNULL(a.ReportPeriod,b.ReportPeriod) as ReportPeriod,	
	   ISNULL(a.NumberOfDays,b.NumberOfDays) as NumberOfDays,	
	   ISNULL(a.TotalLogIn,b.TotalLogIn) as TotalLogIn,
       b.[< Login #],
	   b.[> Login #]
from #A365LicensingDashboard_dd as a
Left outer join #A365LicensingDashboard  as b
on a.ReportDate = b.ReportDate
order by a.Id


