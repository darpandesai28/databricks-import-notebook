IF object_id('a365.LicensingDashboard') is not null
drop table a365.LicensingDashboard

Create table a365.LicensingDashboard
(
id int NOT NULL,
ReportDate varchar(50),
ReportFullDate date,
ReportPeriod varchar(25),
NumberOfDays int,
TotalLogIn int,
[< Login #] int NULL,
[> Login #] int NULL
)
with
(
DISTRIBUTION = REPLICATE,
CLUSTERED INDEX (id)

);
Insert into a365.LicensingDashboard
(
id,
ReportDate,
ReportFullDate,
ReportPeriod,
NumberOfDays,
TotalLogIn)
select 1,'1-Oct-'+ RIGHT(cast(year(getdate()) as varchar(4)),2),cast(year(getdate()) as varchar(4)) + '-10-01','Sep',30,29
UNION
select 2,'1-Nov-'+ RIGHT(cast(year(getdate()) as varchar(4)),2),cast(year(getdate()) as varchar(4)) + '-11-01','Oct',31,29
UNION
select 3,'1-Dec-'+ RIGHT(cast(year(getdate()) as varchar(4)),2),cast(year(getdate()) as varchar(4)) + '-12-01','Nov',30,29
UNION
select 4,'1-Jan-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-01-01','Nov - Dec',61,58
UNION
select 5,'1-Feb-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-02-01','Nov - Jan',92,87
UNION
select 6,'1-Mar-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-03-01','Nov - Feb',120,116
UNION
select 7,'1-Apr-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-04-01','Nov - Mar',151,146
UNION
select 8,'1-May-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-05-01','Nov - Apr',181,175
UNION
select 9,'1-Jun-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-06-01','Nov - May',212,204
UNION
select 10,'1-Jul-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-07-01','Nov - Jun',242,233
UNION
select 11,'1-Aug-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-08-01','Nov - Jul',273,262
UNION
select 12,'1-Sep-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-09-01','Nov - Aug',304,291
UNION
select 13,'1-Oct-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-10-01','Nov - Sep',334,321
UNION
select 14,'1-Nov-'+ RIGHT(cast(year(getdate()) + 1 as varchar(4)),2),cast(year(getdate()) + 1 as varchar(4)) + '-11-01','Nov - Oct',365,350

--Select * from a365.LicensingDashboard