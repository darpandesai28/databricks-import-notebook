/*
SELECT count(distinct lastActivityDate),
min(lastActivityDate),
max(lastActivityDate)
FROM [a365].[emailActivity]
WHERE [userKey] = 220387
*/

--emailActivity
IF object_id('tempdb.dbo.#emailActivity') is not null
drop table #emailActivity

Declare @emailActivity_reportRefreshDate date
SET @emailActivity_reportRefreshDate = (select Max(reportRefreshDate) from [a365].[emailActivity])

SELECT [userKey]
      ,[Count of Activity] = COUNT(Distinct lastActivityDate)
into #emailActivity 
FROM [a365].[emailActivity]
WHERE DATEDIFF(day, lastActivity[date] NULL, @emailActivity_reportRefreshDate) <=  @NumberOfDays
group by [userKey]

--onedriveActivity
IF object_id('tempdb.dbo.#onedriveActivity') is not null
drop table #onedriveActivity

Declare @onedriveActivity_reportRefreshDate date
SET @onedriveActivity_reportRefreshDate = (select Max(reportRefreshDate) from [a365].[onedriveActivity])

SELECT [userKey]
      ,[Count of Activity] = COUNT(Distinct lastActivityDate)
into #onedriveActivity
FROM [a365].[onedriveActivity]
WHERE DATEDIFF(day, lastActivity[date] NULL, @onedriveActivity_reportRefreshDate) <=  @NumberOfDays
group by [userKey]

--sharepointActivity
IF object_id('tempdb.dbo.#sharepointActivity') is not null
drop table #sharepointActivity

Declare @sharepointActivity_reportRefreshDate date
SET @sharepointActivity_reportRefreshDate = (select Max(reportRefreshDate) from [a365].[sharepointActivity])

SELECT [userKey]
      ,[Count of Activity] = COUNT(Distinct lastActivityDate)
into #sharepointActivity
FROM [a365].[sharepointActivity]
WHERE DATEDIFF(day, lastActivity[date] NULL, @sharepointActivity_reportRefreshDate) <=  @NumberOfDays
group by [userKey]

--teamsActivity
IF object_id('tempdb.dbo.#teamsActivity') is not null
drop table #teamsActivity

Declare @teamsActivity_reportRefreshDate date
SET @teamsActivity_reportRefreshDate = (select Max(reportRefreshDate) from [a365].[teamsActivity])

SELECT [userKey]
      ,[Count of Activity] = COUNT(Distinct lastActivityDate)
into #teamsActivity
FROM [a365].[teamsActivity]
WHERE DATEDIFF(day, lastActivity[date] NULL, @teamsActivity_reportRefreshDate) <=  @NumberOfDays
group by [userKey]


IF object_id('tempdb.dbo.#userActivity') is not null
drop table #userActivity

select [userKey]
      ,[Count of Activity] = sum([Count of Activity])
into #userActivity
from (select * from #emailActivity ea
	  UNION ALL
	  select * from #onedriveActivity oa
	  UNION ALL
	  select * from #sharepointActivity sa
	  UNION ALL
	  select * from #teamsActivity ta) as x
Group by [userKey]

Select      
       sum(case when [User_Status] = 'Periodic' then 1 else 0 end) as [Periodic],
	   sum(case when [User_Status] = 'Active' then 1 else 0 end) as [Active]
from
( 
Select [userKey],
       [Count of Activity],
       case when [Count of Activity] < 250 then 'Periodic' else 'Active' end as [User_Status]
from #userActivity ) as x

