# Overview

The purpose of the GitHub repository (repo) titled 'cas-cde-datafactory' is to host the configuration for the integration of Azure Data Factory (ADF) within a repo in the Army EITaaS GitHub organization. By default, the ADF User Experience authors changes directly against the ADF service - you can only save changes by selecting 'Publish All' which publishes each change to ADF directly. Before this repo was created, LOE 1.3 C&S was deploying ADF by exporting an [Azure Resource Manager (ARM)](https://docs.microsoft.com/en-us/azure/azure-resource-manager/management/overview) template based on the ADF User Interface and forwarding it to the Automation/Infrastructure team so that parameters could be updated before deployment via [GitHub Actions](https://docs.github.com/en/actions) took place. By performing the integration that this repo provides, changes that are published to the ADF service are automatically persisted in code to GitHub. Similarly, updates to ADF that are proposed by contributing developers on GitHub can be version controlled to validate functionality before changes are actually published to the ADF service; thus allowing incremental changes to be made to ADF resources only when they have been tested to the development team's satisfaction. 

The Collaborative Data Environment (CDE) team currently uses several Azure environments to validate the functionality of the team's development work: manual-cde, auto-cde (both are sandbox environments), development, and production. Though this repo integration tool is capable of publishing changes to each of these environments, the team has only connected the manual-cde environment to GitHub. When a developer creates a PR off of their [Sprint Branch](https://github.com/ArmyEITaaS/onboarding#cde-sprint-branch-strategy), the workflow defined here will automatically use a new ADF-specific GitHub Action to deploy the changes to each environment (Sandbox, Development, Production). This deployment method also cleans up any ADF artifacts that have been removed in the new ARM template. 

* manual-cde > auto-cde deployment: workflow pulls down all ADF artifacts from GitHub and deploys 
* auto-cde > development deployment: workflow re-uses artifacts instead of pulling them down from GitHub again 
* development > production deployment: workflow re-uses artifacts instead of pulling them down from GitHub again

## Instructions Used to Integrate

* [CI/CD Improvements with GitHub Support in Azure Government](https://techcommunity.microsoft.com/t5/azure-data-factory/cicd-improvements-with-github-support-in-azure-government-and/ba-p/2686918)
* [Connect to a Git Repository](https://docs.microsoft.com/en-us/azure/data-factory/source-control#connect-to-a-git-repository)
* [Author with GitHub Integration](https://docs.microsoft.com/en-us/azure/data-factory/source-control#author-with-github-integration)

You can use both public and private GitHub repos with ADF as long as you have read and write permissions to the repo in GitHub. Connecting to a GitHub organization (org) requires the org to grant permissions to ADF. A user with ADMIN permissions on the org must perform [these steps](https://docs.microsoft.com/en-us/azure/data-factory/source-control#connecting-to-github-for-the-first-time-in-azure-data-factory) to allow ADF to connect. 

## Creating Feature Branches 

- Version control systems let developers collaborate on code/track changes that are made to the code base (between feature branch and collaboration branch). You're only able to publish to the ADF service from your collaboration branch (main is the default).
- By default, ADF generates the ARM template of the published factory/saves them to a branch called 'adf_publish'
- 'publish_config.json' = used to configure a custom publish branch > file is added to the root folder in the collaboration branch. When publishing, ADF reads this file, looks for the field 'publishBranch', and saves all ARM templates to the specified location. 
- ADF can only have one publish branch at a time.

NOTE: Changes made via PowerShell or an SDK are published directly to the ADF service, and are not entered into Git. 

* [Advantages of Git Integration](https://docs.microsoft.com/en-us/azure/data-factory/source-control#advantages-of-git-integration)
* [Limitations of ADF-GitHub Integration](https://docs.microsoft.com/en-us/azure/data-factory/source-control#known-github-limitations)

### GitHub Workflow 

1. Downloads CDE ELT ADF artifact: When the SBX workflow is run, the ADF ARM template is published and uploaded as an artifact within the workflow. This is then downloaded to do the deployment

1. Compresses JSON: This file is compressed to circumvent a size restriction of 4 MB when deploying the ARM template from the workflow

1. Displays structure of downloaded files: This is a verification step to ensure all files exist in the workflow agent

1. Uploads ARM template artifact: The artifact is uploaded to the workflow

1. Connects to Azure Government 

1. Sets up Python 3.0: This is set up in the workflow agent 

1. Installs dependencies: These are the dependencies necessary to execute/utilize [Databricks CLI](https://docs.microsoft.com/en-us/azure/databricks/dev-tools/cli/)

1. Downloads & installs Databricks CLI: This is installed on the workflow agent 

1. Logs in to Databricks with SPN, gets ADF Cluster ID, deploys ADF ARM template, logs out 

## Azure Data Factory

Enterprises hold data in disparate sources on-premises or in the cloud in structured, semi-structured, and unstructured formats *all arriving at different intervals and speeds*. On its own, raw data doesn't have the proper context or meaning to provide useful insights. ADF is a managed cloud service that is built for complex ETL and data integration projects. It is used to create and schedule data driven workflows (pipelines) that can ingest data from disparate data stores, transform it, and publish your transformed data to data stores such as Azure Synapse Analytics for Business Intelligence (BI) apps to consume. Ultimately, through ADF, raw data can be organized into meaningful data stores and data lakes for better business decisions. In all regions, ADF data is stored and replicated in the [paired region](https://docs.microsoft.com/en-us/azure/virtual-machines/regions#region-pairs) to protect against metadata loss. When a failover is completed, you will be able to access your ADF in the failover region. For EITaaS, ADF orchestrates the other resources and services being leveraged to have data flow through the entire system in the following manner:

i. Pull Data: this takes place by ADF performing via an API call, a command being sent to [Databricks](https://docs.microsoft.com/en-us/azure/databricks/scenarios/what-is-azure-databricks-ws), or is natively performed by Azure Diagnostics. 

ii. Transform Data: ADF communicates to Databricks when to move data from our [Delta Lake](https://docs.microsoft.com/en-us/azure/databricks/delta/) raw tables to Delta Lake stage tables. 

iii. Move Data to Synapse: ADF communicates to Databricks to move data from Delta Lake stage tables to [Azure Synapse](https://docs.microsoft.com/en-us/azure/synapse-analytics/overview-what-is) stage tables. 

iv. Move Data to Synapse Dimension and Fact Tables: ADF communicates to Synapse to move data from the Synapse stage tables into the various Dims and Facts. This is the final resting place of the data from which PowerBI reads it to create the CDE reports based on [Views](https://docs.microsoft.com/en-us/sql/relational-databases/views/views?view=sql-server-ver15#types-of-views) created in Synapse.

NOTE: Data Flows is a garphical UI for data transformation that uses Databricks on the backend. The CDE is not utilizing this tool for development but is rather calling Databricks directly.

### Alerting 

Alerting on ADF ETL failures has been configured to route email notifications to a defined distribution group. However, it is planned to amend the current approach to process alerts by using a [Logic App](https://docs.microsoft.com/en-us/azure/logic-apps/logic-apps-overview) instead. This change will be deployed as a part of the [cas-cde-infra](https://github.com/ArmyEITaaS/cas-cde-infra) repo at a future date.

### ADF Terminology/Components 

#### ETL = Extract, Transform, Load

* Extract: connect to sources, copy data to central store 
* Transform: process the data for analysis
* Load: move to data warehouse or analytics engine 

#### Data Sets

Datasets represent data structures within data stores. They point to or reference the data that you want to use in your activities as inputs or outputs. 

#### Integration Runtime (IR)

An IR provides the bridge between an ADF 'activity' and a 'linked service' in that it *provides the compute environment* where the activity either runs or gets dispatched from. An IR is the compute infrastructure used by ADF pipelines. 

#### Linked Services

Linked Services define the connection information that ADF needs in order to connect to external resources e.g. it defines the connection to the target data source. In the context of ADF, Linked Services are used for two reasons: 

1. To represent a data store such as SQL Server DB, Oracle DB, File Share, or Blob Storage Account 
1. To represent a compute resource that can host the execution of an activity.

#### Pipelines and Activities

A Pipeline is a logical grouping of activities that performs a unit of work. Together, the individual activities in a pipeline perform a task. The benefit of this is that pipelines allow you to manage activities as a set instead of individually. Activities in a pipeline can operate sequentially (chained) or independently/in parallel. An ADF instance can have more than one pipeline. A 'pipeline run' represents a single instance of a pipeline execution. They are typically instantiated by passing arguments to the parameters that are defined in pipelines. These arguments can be passed manually or within a trigger definition.

- Each pipeline run has a unique run ID (A GUID that defines that particular run).
- Manual Execution aka 'On-Demand' can be executed in a variety of ways, including PS modules, REST APIs, or Python SDKs
- Example: a pipeline could contain a set of activities that ingest and clean log data, then kick off a mapping data flow to analyze the log data 

An Activity is a processing step in a pipeline. ADF supports 3x types of activities: 

1. Data movement 
1. Data transformation 
1. Control activities 

- Example: a 'copy activity' could be used to copy data from SQL Server to an Azure BLOB. Then, a dataflow activity or a Databricks Notebook activity could be used to process and transform the data from the Blob to a Synapse Analytics pool.

#### Triggers 

Triggers represent the unit of processing that determines when pipeline execution needs to be kicked off. The 'ETL Refresh Rate' tab of the following spreadsheet annotates the types of triggers being used by the CDE team: [Modular_Design](https://microsoft.sharepoint.com/teams/ArmyEITaaSPilot/_layouts/15/Doc.aspx?sourcedoc=%7BBB263B9B-A5C0-413A-89D9-CAFB8261CFC6%7D&file=Modular_Design.xlsx&action=default&mobileredirect=true&DefaultItemOpen=1). Currently, ADF supports 3x types of triggers: 

1. Schedule: invokes pipeline on wall-clock schedule. These are marked as successful as long as a pipeline run is *started*
2. Tumbling Window: Operates on a periodic interval, while also retaining state 
3. Event-based: a trigger that responds to an event (Storage or Custom)

* Storage Event: pipeline runs against events in a Storage Account (arrival/deletion of a file)
* Custom Event: defined as a topic in Azure Event Grid

* PIPELINES AND TRIGGERS HAVE A MANY-TO-MANY RELATIONSHIP (EXCEPT FOR TUMBLING WINDOW) 

