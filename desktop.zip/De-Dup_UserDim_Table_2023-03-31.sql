SELECT DISTINCT 
   TABLE_SCHEMA+ '.' + TABLE_NAME
FROM 
   INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME = 'userKey'

/*
	a365.activeUserLicense
	a365.emailActivity
	a365.mailboxUsage
	a365.officeActivation
	a365.onedriveActivity
	a365.onedriveUsage
	a365.sharepointActivity
	a365.sharepointUsage
	a365.teamsActivity
	dbo.commentFct
	dbo.deviceFct
	dbo.spSignInFct
	dbo.upSignInFct
	device.deviceCompliancePolicyFct
*/

if object_id('tempdb.dbo.#dupUsers') is not null
	drop table #dupUsers

select * into #dupUsers
from
(Select userKey,userPrincipalName,checksum,row_number() over (partition by userPrincipalName ,checksum order by whenUpdated DESC) as RNum
FROM [dbo].userDim usd ) as x
where x.RNum >= 2

if object_id('tempdb.dbo.#userKey') is not null
	drop table #userKey

Select userKey,userPrincipalName 
into #userKey
FROM [dbo].userDim usd
						where usd.userPrincipalName IN (Select userPrincipalName from #dupUsers)
						and checksum IN (Select checksum from #dupUsers)

 if object_id('tempdb.dbo.#old_new_userKeyLup') is not null
	drop table #old_new_userKeyLup

 Select distinct ISNULL(new_uk.userPrincipalName,old_uk.userPrincipalName) as userPrincipalName,
        new_uk.userKey as new_userKey,
        old_uk.userKey as old_userKey
 INTO #old_new_userKeyLup
 from (Select * from #userKey where userKey NOT IN (select userKey from #dupUsers)) as new_uk
 INNER JOIN #dupUsers old_uk
   on new_uk.userPrincipalName = old_uk.userPrincipalName
   
--Delete from [dbo].userDim
Select * from [dbo].userDim where userKey IN (Select userKey from #dupUsers)
--DELETE from [dbo].userDim where userKey IN (Select userKey from #dupUsers)

--Update activeUserLicense FACT table
Select aul.userKey,ukl.old_userKey,ukl.new_userKey,aul.userPrincipalName 
from a365.activeUserLicense aul
inner join #old_new_userKeyLup ukl
 on aul.userKey = ukl.old_userKey
/*
update aul
set aul.userKey = ukl.new_userKey 
from a365.activeUserLicense aul
inner join #old_new_userKeyLup ukl
 on aul.userKey = ukl.old_userKey
*/

Select top 1 * from a365.activeUserLicense where userKey IN (Select userKey from #dupUsers)
Select top 1 * from a365.emailActivity where userKey IN (Select userKey from #dupUsers)
Select top 1 * from a365.mailboxUsage where userKey IN (Select userKey from #dupUsers)
Select top 1 * from a365.officeActivation where userKey IN (Select userKey from #dupUsers)
Select top 1 * from a365.onedriveActivity where userKey IN (Select userKey from #dupUsers)

Select top 1 * from a365.onedriveUsage where userKey IN (Select userKey from #dupUsers)
Select top 1 * from a365.sharepointActivity where userKey IN (Select userKey from #dupUsers)
--Select top 1 * from a365.sharepointUsage where userKey IN (Select userKey from #dupUsers)
--Select top 1 * from a365.sharepointUsage where userKey IN (Select userKey from #userKey)
Select top 1 * from a365.teamsActivity where userKey IN (Select userKey from #dupUsers)
--Select top 1 * from dbo.commentFct where userKey IN (Select userKey from #dupUsers)
--Select top 1 * from dbo.commentFct where userKey IN (Select userKey from #userKey)


--Select top 1 * from dbo.deviceFct where userKey IN (Select userKey from #dupUsers)
--Select top 1 * from dbo.deviceFct where userKey IN (Select userKey from #userKey)
Select top 1 * from dbo.spSignInFct where userKey IN (Select userKey from #dupUsers)
Select top 1 * from dbo.upSignInFct where userKey IN (Select userKey from #dupUsers)
--Select top 1 * from device.deviceCompliancePolicyFct where userKey IN (Select userKey from #dupUsers)
--Select top 1 * from device.deviceCompliancePolicyFct where userKey IN (Select userKey from #userKey)


--Testing/Spot check script
--Select * from #userKey where userPrincipalName = 'mi.j.song2.civ@army.mil'
--Select * from #dupUsers where userPrincipalName = 'mi.j.song2.civ@army.mil'





   