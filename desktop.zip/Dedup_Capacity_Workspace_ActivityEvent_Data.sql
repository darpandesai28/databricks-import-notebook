-- De-Dup [cdereporting].[pbiWorkspace] Table
;with pbiWorkspace
as (SELECT workspaceId,generatedDateTime,pbiWorkspaceKey,
      	   ROW_NUMBER() OVER(PARTITION BY workspaceId ORDER BY generatedDateTime DESC) AS Row#
  FROM [cdereporting].[pbiWorkspace])
select * from pbiWorkspace where Row# <> 1
--delete from pbiWorkspace where Row# <> 1

/*
-- De-Dup [cdereporting].[pbiCapacity] Table
;with pbiCapacity
as (SELECT capacityId,generatedDateTime,pbiCapacityKey,
      	   ROW_NUMBER() OVER(PARTITION BY capacityId ORDER BY generatedDateTime DESC) AS Row#
  FROM [cdereporting].[pbiCapacity])
--select * from pbiCapacity where Row# <> 1
delete from pbiCapacity where Row# <> 1
*/

-- De-Dup [cdereporting].[pbiCapacity] Table
;with pbiCapacity AS(
    SELECT capacityId,generatedDateTime,pbiCapacityKey,
      	   ROW_NUMBER() OVER(PARTITION BY capacityId ORDER BY generatedDateTime DESC) AS Row#
  FROM [cdereporting].[pbiCapacity]
    )

SELECT * FROM [cdereporting].[pbiCapacity]
WHERE EXISTS (
    SELECT *
    FROM pbiCapacity 
    WHERE [cdereporting].[pbiCapacity].[capacityId] = pbiCapacity.[capacityId]
    AND [cdereporting].[pbiCapacity].[generatedDateTime] = pbiCapacity.[generatedDateTime]
    AND [cdereporting].[pbiCapacity].[pbiCapacityKey] = pbiCapacity.[pbiCapacityKey]
    AND pbiCapacity.Row# <> 1
)

-- De-Dup [cdereporting].[pbiActivityEvent] Table
;with pbiActivityEvent
as (SELECT activityEventId,generatedDateTime,pbiActivityEventKey,
      	   ROW_NUMBER() OVER(PARTITION BY activityEventId ORDER BY generatedDateTime DESC) AS Row#
  FROM [cdereporting].[pbiActivityEvent])
select * from pbiActivityEvent where Row# <> 1
--delete from pbiActivityEvent where Row# <> 1

 SELECT capacityId,count(distinct capacityId)
  FROM [cdereporting].[pbiCapacity]
  group by capacityId
  having count(*)>1

  Select * from [cdereporting].[pbiCapacity] where capacityId = 'E4105A58-31E3-44FA-8A55-0EF73EB6679C'
E4105A58-31E3-44FA-8A55-0EF73EB6679C
E4105A58-31E3-44FA-8A55-0EF73EB6679C

;with pbiCapacity AS(
    SELECT capacityId,generatedDateTime,pbiCapacityKey,
      	   ROW_NUMBER() OVER(PARTITION BY capacityId ORDER BY generatedDateTime DESC) AS Row#
  FROM [cdereporting].[pbiCapacity]
    )
Select * from pbiCapacity
