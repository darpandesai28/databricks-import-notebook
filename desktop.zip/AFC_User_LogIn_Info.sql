IF object_id('tempdb.dbo.#t') is not null
	drop table #t
create table #t (userPrincipalName varchar(100));
insert into #t values ('adam.t.nisson.civ');
insert into #t values ('adan.parra1.mil');
insert into #t values ('adrian.p.fyfe.fm');
insert into #t values ('adrian.v.smith.mil');
insert into #t values ('adrian.velez.mil');
insert into #t values ('aldo.d.abitbol.civ');
insert into #t values ('aldo.j.castro-santos.civ');
insert into #t values ('alex.g.ornstein2.civ');
insert into #t values ('alex.j.suchland.civ');
insert into #t values ('alexandra.t.cromie.mil');
insert into #t values ('amaury.b.ochart.civ');
insert into #t values ('ambrose.c.rosario.civ');
insert into #t values ('ammar.m.masoud.mil');
insert into #t values ('analyn.r.rodriguez.civ');
insert into #t values ('andrea.l.gwynn.civ');
insert into #t values ('angela.n.nichols4.civ');
insert into #t values ('anita.a.howard4.civ');
insert into #t values ('anna.magazinnik.civ');
insert into #t values ('anthony.e.hughley.mil');
insert into #t values ('arjun.kurup.civ');
insert into #t values ('arturo.cornejo.civ');
insert into #t values ('aubrey.s.lavitoria.civ');
insert into #t values ('augusta.z.hemann.civ');
insert into #t values ('austin.a.boone.mil');
insert into #t values ('barbara.j.calhoun2.civ');
insert into #t values ('billie.l.stokes.civ');
insert into #t values ('billy.r.michael4.civ');
insert into #t values ('blake.m.macon.civ');
insert into #t values ('blas.c.rueda-caraballo.civ');
insert into #t values ('brent.o.skinner.mil');
insert into #t values ('brian.a.sessler.civ');
insert into #t values ('brianne.l.ewing.mil');
insert into #t values ('bryan.p.jonas.mil');
insert into #t values ('cali.d.garcia.civ');
insert into #t values ('candace.e.akins.civ');
insert into #t values ('carl.e.tucker.civ');
insert into #t values ('carl.w.hale4.civ');
insert into #t values ('carolina.cruz.mil');
insert into #t values ('catherine.g.robertson.mil');
insert into #t values ('celeste.j.kennamer.civ');
insert into #t values ('charles.w.broughton.civ');
insert into #t values ('charlotte.m.cordero.civ');
insert into #t values ('christine.a.carruthers.civ');
insert into #t values ('christine.d.dash.civ');
insert into #t values ('christopher.a.linz.civ');
insert into #t values ('christopher.c.brewton.civ');
insert into #t values ('christopher.d.lovelace4.civ');
insert into #t values ('christopher.harvey3.mil');
insert into #t values ('christopher.j.lowrance.mil');
insert into #t values ('christopher.j.zimmer2.mil');
insert into #t values ('christopher.m.cummings3.civ');
insert into #t values ('christopher.m.ford6.mil');
insert into #t values ('christopher.s.cropper.ctr');
insert into #t values ('colin.darby.civ');
insert into #t values ('connor.a.maloney.civ');
insert into #t values ('corey.a.walker7.mil');
insert into #t values ('corey.g.halterman.ctr');
insert into #t values ('cory.j.delger.mil');
insert into #t values ('cynthia.l.pittman.civ');
insert into #t values ('cynthia.m.fiorino.ctr');
insert into #t values ('danarius.m.hemphill.civ');
insert into #t values ('daniel.h.kane.civ');
insert into #t values ('dante.e.milledge.civ');
insert into #t values ('darrin.h.kay.civ');
insert into #t values ('davey.p.vargas.civ');
insert into #t values ('david.f.farias.civ');
insert into #t values ('david.j.docimo.civ');
insert into #t values ('david.l.futch2.civ');
insert into #t values ('david.r.lamy.mil');
insert into #t values ('david.s.huerta2.civ');
insert into #t values ('david.s.thompson56.civ');
insert into #t values ('dina.mabry.civ');
insert into #t values ('dionne.r.dunham.civ');
insert into #t values ('dustin.j.rhine.ctr');
insert into #t values ('ebony.a.jolly.mil');
insert into #t values ('edward.r.phelps4.ctr');
insert into #t values ('edwin.delacruz2.mil');
insert into #t values ('elise.m.joseph2.civ');
insert into #t values ('elizabeth.a.arwine.civ');
insert into #t values ('elizabeth.a.kissee.civ');
insert into #t values ('elliot.d.werner.mil');
insert into #t values ('elva.madrigal.civ');
insert into #t values ('elvis.l.ruiz2.civ');
insert into #t values ('emily.c.arzaga.civ');
insert into #t values ('enrique.rivera1.civ');
insert into #t values ('eric.c.rishel.civ');
insert into #t values ('eric.d.greer.civ');
insert into #t values ('eric.j.carreau.civ');
insert into #t values ('erica.l.graves4.civ');
insert into #t values ('erica.s.fessler.civ');
insert into #t values ('erick.a.kelemen.ctr');
insert into #t values ('fawn.n.miller.civ');
insert into #t values ('felicia.r.owens.civ');
insert into #t values ('frances.c.kauhl.mil');
insert into #t values ('francisco.torres20.civ');
insert into #t values ('gary.h.gonzalez.civ');
insert into #t values ('george.k.gordon.civ');
insert into #t values ('gerhard.w.rickert.ctr');
insert into #t values ('gina.e.adam.mil');
insert into #t values ('glidden.j.torres-estela.civ');
insert into #t values ('gregory.m.hotchkiss.civ');
insert into #t values ('gregory.r.smith3.civ');
insert into #t values ('haley.a.steele.mil');
insert into #t values ('hans.b.honerlah.civ');
insert into #t values ('hector.l.rivera3.civ');
insert into #t values ('hoa.a.diep.mil');
insert into #t values ('indira.g.williams.civ');
insert into #t values ('isaiah.delgado.ctr');
insert into #t values ('israel.guzmanferrer.ctr');
insert into #t values ('jack.h.cooperman.mil');
insert into #t values ('jackie.r.ashley.ctr');
insert into #t values ('jacob.a.bowen8.mil');
insert into #t values ('jacqueline.m.newell.mil');
insert into #t values ('james.l.denton.civ');
insert into #t values ('james.m.martin2.civ');
insert into #t values ('james.r.orbock2.civ');
insert into #t values ('jamie.l.protte.civ');
insert into #t values ('jana.d.torres.civ');
insert into #t values ('javier.o.rogelespinoza.civ');
insert into #t values ('jay.c.coats.mil');
insert into #t values ('jeffrey.e.baker12.mil');
insert into #t values ('jeffrey.l.withers.civ');
insert into #t values ('jeffrey.r.kwasniewski.civ');
insert into #t values ('jennifer.c.brewster.mil');
insert into #t values ('jennifer.l.pacheco19.civ');
insert into #t values ('jeremiah.d.collins.civ');
insert into #t values ('jessica.m.collins26.civ');
insert into #t values ('jimmy.o.perez.civ');
insert into #t values ('jody.d.morris.civ');
insert into #t values ('jody.m.pappenfus.civ');
insert into #t values ('johanna.t.wynne.mil');
insert into #t values ('john.c.kump.mil');
insert into #t values ('john.d.barrington.mil');
insert into #t values ('john.h.untersee.civ');
insert into #t values ('john.m.keeter2.civ');
insert into #t values ('johnna.i.thompson.civ');
insert into #t values ('jon.p.martel.civ');
insert into #t values ('jonathan.a.bodenhamer.mil');
insert into #t values ('jonathan.lee30.civ');
insert into #t values ('jose.p.mendoza.mil');
insert into #t values ('jose.r.latorre2.mil');
insert into #t values ('joseph.a.wucik.civ');
insert into #t values ('joseph.i.gilbert.mil');
insert into #t values ('joseph.j.stanko.civ');
insert into #t values ('joshua.l.bodenheimer.civ');
insert into #t values ('joy.l.allen10.mil');
insert into #t values ('juan.c.segura.mil');
insert into #t values ('judy.e.crowder.civ');
insert into #t values ('julian.q.mcmillan.civ');
insert into #t values ('justin.l.ramirez2.ctr');
insert into #t values ('justin.r.lafleur.ctr');
insert into #t values ('kara.l.stetson.civ');
insert into #t values ('karma.k.vance.civ');
insert into #t values ('kathryn.s.mather.civ');
insert into #t values ('katrina.m.mansfield.civ');
insert into #t values ('kelsey.d.kennard.mil');
insert into #t values ('kenneth.m.wanless2.mil');
insert into #t values ('kenneth.t.loncarich.civ');
insert into #t values ('kenton.b.satterwhite.mil');
insert into #t values ('kevin.p.leitch.civ');
insert into #t values ('kim.m.mcgraw.civ');
insert into #t values ('kimberly.y.stewart.civ');
insert into #t values ('kizzy.mayfield2.civ');
insert into #t values ('kristopher.j.weygant.civ');
insert into #t values ('lailaan.m.anderson.mil');
insert into #t values ('lakreisha.l.johnson.civ');
insert into #t values ('lashonda.n.williams2.civ');
insert into #t values ('lawrence.m.stout.civ');
insert into #t values ('leah.r.lucio.civ');
insert into #t values ('leslie.d.figueroa.civ');
insert into #t values ('liam.j.kozma.mil');
insert into #t values ('linda.destasi.civ');
insert into #t values ('lisa.formoso.civ');
insert into #t values ('lisa.k.cramer.civ');
insert into #t values ('lisa.m.castro6.civ');
insert into #t values ('logan.m.bywater.ctr');
insert into #t values ('lorrie.a.espinoza2.ctr');
insert into #t values ('louis.c.brousseau.civ');
insert into #t values ('louis.p.hawkins.mil');
insert into #t values ('lucas.e.brown.mil');
insert into #t values ('luis.g.gutierrez10.mil');
insert into #t values ('lydie.louis.civ');
insert into #t values ('marcus.r.stone.ctr');
insert into #t values ('margaret.e.morris10.civ');
insert into #t values ('maria.a.ehmann.civ');
insert into #t values ('maribel.l.rambuyan.civ');
insert into #t values ('mario.a.gonzalezgonzalez.civ');
insert into #t values ('mario.j.lamaestra.ctr');
insert into #t values ('marlowe.richmond.civ');
insert into #t values ('martin.pescador.mil');
insert into #t values ('mary.a.adams.civ');
insert into #t values ('mary.a.beadles.civ');
insert into #t values ('mary.l.dingle2.civ');
insert into #t values ('mary.l.fuhr.civ');
insert into #t values ('mary.m.howes.civ_mail.mil#EXT#');
insert into #t values ('matthew.c.benigni.mil');
insert into #t values ('matthew.j.giltenan.mil');
insert into #t values ('matthew.j.shively.ctr');
insert into #t values ('md.s.rana.civ');
insert into #t values ('melissa.s.walker.civ');
insert into #t values ('melody.a.velasquez.mil');
insert into #t values ('merissa.s.mccall.civ');
insert into #t values ('michael.a.diubaldi.civ');
insert into #t values ('michael.a.pelzner.mil');
insert into #t values ('michael.e.mcinerney.mil');
insert into #t values ('michael.g.pond.mil');
insert into #t values ('michael.l.davis16.ctr');
insert into #t values ('michael.m.mejia.civ');
insert into #t values ('michael.p.bosco2.ctr');
insert into #t values ('michael.r.warpinski.mil');
insert into #t values ('michael.s.goodwin10.civ');
insert into #t values ('michael.t.ertmer.ctr');
insert into #t values ('michael.w.oxner.ctr');
insert into #t values ('michael.r.howard18.civ');
insert into #t values ('michele.m.simmons2.civ');
insert into #t values ('michelle.l.davis104.civ');
insert into #t values ('michelle.l.thomas40.civ');
insert into #t values ('monica.h.george.civ');
insert into #t values ('monica.m.holmes2.mil');
insert into #t values ('newman.m.yang.civ');
insert into #t values ('nicholas.e.park.mil');
insert into #t values ('nicholas.s.gresko.mil');
insert into #t values ('nilsa.g.ferrell.civ');
insert into #t values ('noga.hudson.civ');
insert into #t values ('pamela.m.stephens6.civ');
insert into #t values ('patricia.v.rivera.civ');
insert into #t values ('patrick.d.morse2.civ');
insert into #t values ('patrick.j.badar.civ');
insert into #t values ('peter.a.newvine2.mil');
insert into #t values ('peter.b.thomas.civ');
insert into #t values ('petrina.t.mcintyre.civ');
insert into #t values ('phenize.howell2.mil');
insert into #t values ('rand.a.rodriguez.civ');
insert into #t values ('randy.j.grunow.civ');
insert into #t values ('randy.p.lefebvre.mil');
insert into #t values ('rebecca.s.goering.civ');
insert into #t values ('regina.l.dunlap.ctr');
insert into #t values ('reginald.l.freeman10.ctr');
insert into #t values ('richard.m.bailey1.civ');
insert into #t values ('richard.r.reagan.civ');
insert into #t values ('ricky.a.hunter10.ctr');
insert into #t values ('robby.d.height.civ');
insert into #t values ('robert.c.washington.civ');
insert into #t values ('robert.j.ortiz4.civ');
insert into #t values ('robert.l.pena.civ');
insert into #t values ('robert.m.golias.civ');
insert into #t values ('robert.t.mullen.mil');
insert into #t values ('robert.w.greer.civ');
insert into #t values ('roberto.nunez.mil');
insert into #t values ('robyn.l.ackerman.mil');
insert into #t values ('robyn.m.mack.civ');
insert into #t values ('ronald.d.sullivan.civ');
insert into #t values ('ronald.g.galloway3.civ');
insert into #t values ('russell.a.ferrell2.civ');
insert into #t values ('russell.t.butler2.civ');
insert into #t values ('ruth.m.foutz.civ');
insert into #t values ('ryan.j.esquivel.ctr');
insert into #t values ('ryan.j.sills.civ');
insert into #t values ('ryan.r.demarco.mil');
insert into #t values ('sabrina.n.ayers.civ');
insert into #t values ('sarah.c.kelley5.mil');
insert into #t values ('scott.m.brady.civ');
insert into #t values ('seth.w.wacker.mil');
insert into #t values ('shannon.l.graham12.civ');
insert into #t values ('shanteller.l.mouton.civ');
insert into #t values ('sharon.r.crumblin.civ');
insert into #t values ('sheerann.m.moulton.civ');
insert into #t values ('shonnette.g.rana.mil');
insert into #t values ('sonja.l.nelson2.civ');
insert into #t values ('sophea.siv-kaholo.civ');
insert into #t values ('stacy.j.vicari.civ');
insert into #t values ('stephanie.n.lopez.ctr');
insert into #t values ('stephanie.r.johns.civ');
insert into #t values ('stephen.g.shirley2.civ');
insert into #t values ('steven.garcia14.mil');
insert into #t values ('steven.l.wallace4.civ');
insert into #t values ('stuart.w.wells.civ');
insert into #t values ('sur.e.stewart.civ');
insert into #t values ('susan.a.malanga.civ');
insert into #t values ('suzanne.r.torres.civ');
insert into #t values ('tamika.y.robinson.civ');
insert into #t values ('tara.n.lancaster.civ');
insert into #t values ('tawayna.s.washington2.mil');
insert into #t values ('terrence.d.obrien.civ');
insert into #t values ('thomas.h.cowan2.civ');
insert into #t values ('thomas.j.kelly2.civ');
insert into #t values ('timothy.c.tarr.civ');
insert into #t values ('timothy.sugars.mil');
insert into #t values ('tonya.s.sanders2.civ');
insert into #t values ('tracey.m.brunson.civ');
insert into #t values ('tracy.l.smith3.ctr');
insert into #t values ('tracylynn.c.howard.civ');
insert into #t values ('trevor.s.voelkel.mil');
insert into #t values ('trinette.l.coleman.civ');
insert into #t values ('tyler.j.morrow9.mil');
insert into #t values ('tyrone.washington5.mil');
insert into #t values ('vanessa.m.jackson.civ');
insert into #t values ('vanessa.y.millett.civ');
insert into #t values ('varman.s.chhoeung.mil');
insert into #t values ('victoria.a.dixon2.civ');
insert into #t values ('vincent.w.valerian.civ');
insert into #t values ('wallenia.s.thompson.ctr');
insert into #t values ('wesley.a.carter3.civ');
insert into #t values ('wesley.j.kwasney.mil');
insert into #t values ('william.a.glass8.civ');
insert into #t values ('william.m.mizell.civ');
insert into #t values ('william.m.pollock9.civ');
insert into #t values ('willie.kinsey3.civ');
insert into #t values ('wilma.l.crawley.civ');
insert into #t values ('xarhya.wulf.civ');
insert into #t values ('yomaris.correa.civ');
insert into #t values ('michael.r.dembeck.mil');

IF object_id('tempdb.dbo.#afct') is not null
	drop table #afct
Select t.userPrincipalName,
      uD.uPN, 
	  uD.unitName, 
	  ap.applicationName, 
	  dv.deviceName,
	  up.generatedDateTime
into #afct
from #t t
Left outer join 
(select distinct userKey,userPrincipalName as uPN,unitName, 
 Substring(replace(userPrincipalName,'disable.',''),1,charindex('@',replace(userPrincipalName,'disable.',''))-1) as userPrincipalName
  from dbo.userdim
 where charindex('@',replace(userPrincipalName,'disable.','')) > 0) as uD
 on t.userPrincipalName = uD.userPrincipalName
 --order by 2
 left join [dbo].[upSignInFct] up
	on up.userKey = uD.userKey
 left join dbo.applicationDim ap
	on up.applicationKey = ap.applicationKey
 left join dbo.deviceDim dv
	on up.deviceKey = dv.deviceKey
--where ap.applicationName = 'Windows Sign In'
  --and (deviceName like 'AFC%' or deviceName like 'PAW%' or deviceName like 'SPE%' or deviceName like 'EUD%')
 

select userPrincipalName, 
max(case when applicationName = 'Windows Sign In' 
and  (deviceName like 'AFC%' or deviceName like 'PAW%' or deviceName like 'SPE%' or deviceName like 'EUD%')
  then cast(generatedDateTime as date) else NULL end) as lastLoginDate-- consolidate for the last login date
from #afct 
group by userPrincipalName
order by userPrincipalName 


select userPrincipalName, applicationName,deviceName,cast(generatedDateTime as date)

from #afct 
where userPrincipalName ='adrian.v.smith.mil'
group by userPrincipalName
order by userPrincipalName 