if object_id('tempdb.dbo.#baseTable') is not null
   drop table #baseTable
Select * into #baseTable 
         from diagnostics.vpn

if object_id('tempdb.dbo.#deDup') is not null
   drop table #deDup

Select [checkSum],vpnKey,
row_number() over (partition by [checkSum] order by vpnKey DESC) as rowNumber
into #deDup
from diagnostics.vpn where [checkSum] IN (
										Select  [checkSum]
										from #baseTable
										group by [checkSum]
										having count(*) >1)
--Total Count : 726
--Select count(*) from #deDup
--Distinct checkSum : 357
--Select distinct [checkSum] from #deDup where rowNumber = 1
--DELETE a 
--To be Deleted Duplicate Record Count: 726 - 357 =  369
Select count(*)
--DELETE a
from diagnostics.vpn a
inner join #deDup b
on a.[checkSum] = b.[checkSum]
and a.vpnKey = b.vpnKey
where rowNumber <> 1