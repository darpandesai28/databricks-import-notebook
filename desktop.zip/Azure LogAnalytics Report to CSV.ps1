#The resource URI
$resource = "https://api.loganalytics.us"
#Your Client ID and Client Secret obtained when registering your WebApp
$clientid = "f170da9d-224c-4127-87b4-c52b5446dabe"
$clientSecret = "yHy0_cQPZiBv0aK_pjN4W~Ik_V0bS~d114"
#Your Reply URL configured when registering your WebApp
$redirectUri = "https://localhost"
#Scope
$scope = "Data.Read"
Add-Type -AssemblyName System.Web
#UrlEncode the ClientID and ClientSecret and URL's for special characters
$clientIDEncoded = [System.Web.HttpUtility]::UrlEncode($clientid)
$clientSecretEncoded = [System.Web.HttpUtility]::UrlEncode($clientSecret)
$resourceEncoded = [System.Web.HttpUtility]::UrlEncode($resource)
$scopeEncoded = [System.Web.HttpUtility]::UrlEncode($scope)
#Refresh Token Path
$refreshtokenpath = "C:\pathForYourRT\LogAnalyticsRefresh.token"

#Functions
Function Get-AuthCode {
    Add-Type -AssemblyName System.Windows.Forms
    $form = New-Object -TypeName System.Windows.Forms.Form -Property @{Width = 440; Height = 640 }
    $web = New-Object -TypeName System.Windows.Forms.WebBrowser -Property @{Width = 420; Height = 600; Url = ($url -f ($Scope -join "%20")) }
    $DocComp = {
        $Global:uri = $web.Url.AbsoluteUri        
        if ($Global:uri -match "error=[^&]*|code=[^&]*") { $form.Close() }
    }
    $web.ScriptErrorsSuppressed = $true
    $web.Add_DocumentCompleted($DocComp)
    $form.Controls.Add($web)
    $form.Add_Shown( { $form.Activate() })
    $form.ShowDialog() | Out-Null
    $queryOutput = [System.Web.HttpUtility]::ParseQueryString($web.Url.Query)
    $Global:output = @{ }
    foreach ($key in $queryOutput.Keys) {
        $output["$key"] = $queryOutput[$key]
    }
    $output
}

function Get-AzureAuthN ($resource) {
    # Get Permissions (if the first time, get an AuthCode and Get a Bearer and Refresh Token
    # Get AuthCode   
    $url = "https://login.microsoftonline.us/fae6d70f-954b-4811-92b6-0530d6f84c43/oauth2/authorize?response_type=code&redirect_uri=$redirectUri&client_id=$clientID&resource=$resourceEncoded&scope=$scopeEncoded"
    Get-AuthCode
    # Extract Access token from the returned URI
    $regex = '(?<=code=)(.*)(?=&)'
    
    $authCode = ($uri | Select-String -pattern $regex).Matches[0].Value
    Write-Output "Received an authCode, $authCode"
    #get Access Token
    $body = "grant_type=authorization_code&redirect_uri=$redirectUri&client_id=$clientId&client_secret=$clientSecretEncoded&code=$authCode&resource=$resource"
    $Authorization = Invoke-RestMethod https://login.microsoftonline.us/fae6d70f-954b-4811-92b6-0530d6f84c43/oauth2/token `
        -Method Post -ContentType "application/x-www-form-urlencoded" `
        -Body $body `
        -ErrorAction STOP
    Write-Output $Authorization.access_token
    $Global:accesstoken = $Authorization.access_token
    $Global:refreshtoken = $Authorization.refresh_token 
    if ($refreshtoken) { $refreshtoken | Out-File "$($refreshtokenpath)" }

    if ($Authorization.token_type -eq "Bearer" ) {
        Write-Host "You've successfully authenticated to $($resource) with authorization for $($Authorization.scope)"           
    }
    else {
        Write-Host "Check the console for errors. Chances are you provided the incorrect clientID and clientSecret combination for the API Endpoint selected"
    }
}

function Get-NewTokens {
    # We have a previous refresh token. 
    # use it to get a new token
    $refreshtoken = Get-Content "$($refreshtokenpath)"
    # Refresh the token
    #get Access Token
    $body = "grant_type=refresh_token&refresh_token=$refreshtoken&redirect_uri=$redirectUri&client_id=$clientId&client_secret=$clientSecretEncoded"
    $Global:Authorization = Invoke-RestMethod https://login.microsoftonline.us/fae6d70f-954b-4811-92b6-0530d6f84c43/oauth2/token `
        -Method Post -ContentType "application/x-www-form-urlencoded" `
        -Body $body `
        -ErrorAction STOP
    $Global:accesstoken = $Authorization.access_token
    $Global:refreshtoken = $Authorization.refresh_token
    if ($refreshtoken) {
        $refreshtoken | Out-File "$($refreshtokenpath)"    
        Write-Host "Updated tokens" 
        $Authorization    
        $Global:headerParams = @{'Authorization' = "$($Authorization.token_type) $($Authorization.access_token)" }
    }
} 

$logAnalyticsWorkspace = "0757d021-c2cf-48af-98ef-1d62609b6b65"                        
$logAnalyticsBaseURI = "https://api.loganalytics.us/v1/workspaces"
# $logQuery = "AuditLogs | where SourceSystem == `"Azure AD`" | project Identity, TimeGenerated, ResultDescription | limit 50"
# $logQuery = "AuditLogs | limit 50"

$logQuery = "AzureNetworkAnalytics_CL | project TenantId, SourceSystem, MG, ManagementGroupName, TimeGenerated, Computer, RawData, Tags_s, Subscription1_s, FlowStartTime_s, FASchemaVersion_s, FlowIntervalStartTime_t, FlowIntervalEndTime_t, FlowType_s, FlowStartTime_t, FlowEndTime_t, SrcIP_s, DestIP_s, VMIP_s, DestPort_d, L4Protocol_s, L7Protocol_s, IsFlowCapturedAtUDRHop_b, FlowDirection_s, FlowStatus_s, NSGList_s, NSGRules_s, NSGRule_s, NSGRuleType_s, Subscription1_g, Subscription2_s, Region1_s, Region2_s, NIC_s, NIC1_s, NIC2_s, VM_s, VM1_s, VM2_s, Subnet_s, ApplicationGateway1_s, ApplicationGateway2_s, LoadBalancer1_s, LoadBalancer2_s, LocalNetworkGateway1_s, LocalNetworkGateway2_s, ExpressRouteCircuit1_s, ExpressRouteCircuit2_s, ExpressRouteCircuitPeeringType_s, ConnectionName_s, ConnectingVNets_s, Country_s, AzureRegion_s, AllowedInFlows_d, DeniedInFlows_d, AllowedOutFlows_d, DeniedOutFlows_d, FlowCount_d, InboundPackets_d, OutboundPackets_d, InboundBytes_d, OutboundBytes_d, CompletedFlows_d, PublicIPs_s, SrcPublicIPs_s, DestPublicIPs_s, FlowEndTime_s, batchSizeInBytes_d, NetworkFlowType_s, Subscription2_g, Routes_s, Priority_d, Priority_s, VmssName_s, Status_s, SubscriptionName_s, AddressPrefixes_s, RouteTable_s, AddressPrefix_s, NextHopIP_s, NextHopType_s, FlowLogStorageAccount_s, IsFlowEnabled_b, Access_s, Description_s, DestinationAddressPrefix_s, DestinationPortRange_s, Direction_s, RuleType_s, SourceAddressPrefix_s, SourcePortRange_s, ApplicationGatewayBackendPools_s, EnableIPForwarding_b, LoadBalancerBackendPools_s, MACAddress_s, NSG_s, PrivateIPAddresses_s, PublicIPAddresses_s, Subnetwork_s, VirtualMachine_s, IsVirtualAppliance_b, IPAddress, SubnetPrefixes_s, BGPEnabled_b, GatewayType_s, SKU_s, VIPAddress_s, VirtualSubnetwork_s, VpnClientAddressPrefixes_s, ConnectionStatus_s, ConnectionType_s, EgressBytesTransferred_d, GatewayConnectionType_s, IngressBytesTransferred_d, LocalNetworkGateway_s, Peer_s, RoutingWeight_d, VirtualNetworkGateway1_s, VirtualNetworkGateway2_s, AllowForwardedTraffic_b, AllowGatewayTransit_b, AllowVirtualNetworkAccess_b, UseRemoteGateways_b, VirtualNetwork1_s, VirtualNetwork2_s, AppGatewayType_s, GatewaySubnet_s, PrivateFrontendIPs_s, PublicFrontendIPs_s, BackendSubnets_s, FrontendIPs_s, FrontendSubnet_s, FrontendSubnets_s, LoadBalancerType_s, Subnet1_s, Subnet2_s, SubnetRegion1_s, SubnetRegion2_s, VirtualAppliances_s, BackendIPAddress_s, BackendAddressPool_s, BackendPort_d, FloatingIPEnabled_b, FrontendIPAddress_s, FrontendPort_d, Protocol_s, CircuitProvisioningState_s, ServiceProviderProperties_s, ServiceProviderProvisioningState_s, SkuDetail_s, AzureASN_d, PeerASN_d, PeeringType_s, PrimaryAzurePort_s, PrimaryPeerAddressPrefix_s, PrimarybytesIn_d, PrimarybytesOut_d, SecondaryAzurePort_s, SecondaryPeerAddressPrefix_s, SecondarybytesIn_d, SecondarybytesOut_d, State_s, VlanId_d, SchemaVersion_s, TopologyVersion_s, DiscoveryRegion_s, Name_s, Region_s, ResourceType, SubType_s, Subscription_g, TimeProcessed_t, Network_s, PrimaryNextHop_s, SecondaryNextHop_s, Weight_d, ComponentType_s, Type, _ResourceId"

$logQueryBody = @{"query" = $logQuery } | convertTo-Json

# Get the Log Analytics Data
$result = invoke-RestMethod -method POST -uri "$($logAnalyticsBaseURI)/$($logAnalyticsWorkspace)/query" -Headers @{Authorization = "Bearer $($Global:accesstoken)"; "Content-Type" = "application/json" } -Body $logQueryBody

# Output Columns for CSV
$headerRow = $null
$headerRow = $result.tables.columns | Select-Object name
$columnsCount = $headerRow.Count
# Format the Report
$logData = @()
foreach ($row in $result.tables.rows) {
    $data = new-object PSObject
    for ($i = 0; $i -lt $columnsCount; $i++) {
        $data | add-member -membertype NoteProperty -name $headerRow[$i].name -value $row[$i]
    }
    $logData += $data
    $data = $null
}  

# Export to CSV
$logData | export-csv C:\Users\DarpanDesai\Documents\AzureNetworkAnalytics_CL.csv -NoTypeInformation