if object_id('tempdb.dbo.#baseTable') is not null
   drop table #baseTable
Select * into #baseTable 
         from cdereporting.pbiWorkspace

--Select Top 10 * from #baseTable

if object_id('tempdb.dbo.#deDup') is not null
   drop table #deDup

Select [workspaceId],pbiWorkspaceKey,
row_number() over (partition by [workspaceId] order by pbiWorkspaceKey DESC) as rowNumber
into #deDup
from cdereporting.pbiWorkspace where [workspaceId] IN (
										Select [workspaceId]
										from #baseTable
										group by [workspaceId]
										having count(*) >1)
--Total Count : 1059
--Select count(*) from #deDup
--Distinct checkSum : 529
--Select distinct [workspaceId] from #deDup where rowNumber = 1
--DELETE a 
--To be Deleted Duplicate Record Count: 1059 - 529 =  530
Select count(*)
--DELETE a
from cdereporting.pbiWorkspace a
inner join #deDup b
on a.[workspaceId] = b.[workspaceId]
and a.pbiWorkspaceKey = b.pbiWorkspaceKey
where rowNumber <> 1