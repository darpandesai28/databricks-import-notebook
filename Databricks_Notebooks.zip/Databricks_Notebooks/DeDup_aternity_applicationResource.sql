if object_id('tempdb.dbo.#baseTable') is not null
   drop table #baseTable
Select * into #baseTable 
         from aternity.applicationResource

--Select Top 10 * from #baseTable

if object_id('tempdb.dbo.#deDup') is not null
   drop table #deDup

Select [checkSum],applicationResourceKey,
row_number() over (partition by [checkSum] order by applicationResourceKey DESC) as rowNumber
into #deDup
from aternity.applicationResource where [checkSum] IN (
										Select [checkSum]
										from #baseTable
										group by [checkSum]
										having count(*) >1)
--Total Count : 1059
--Select count(*) from #deDup
--Distinct checkSum : 529
--Select distinct [workspaceId] from #deDup where rowNumber = 1
--DELETE a 
--To be Deleted Duplicate Record Count: 1059 - 529 =  530
Select count(*)
--DELETE a
from aternity.applicationResource a
inner join #deDup b
on a.[checkSum] = b.[checkSum]
and a.applicationResourceKey = b.applicationResourceKey
where rowNumber <> 1