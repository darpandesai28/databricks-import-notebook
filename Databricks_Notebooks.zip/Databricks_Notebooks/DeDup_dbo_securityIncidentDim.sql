if object_id('tempdb.dbo.#baseTable') is not null
   drop table #baseTable
Select * into #baseTable 
         from dbo.securityIncidentDim

--Select Top 10 * from #baseTable

if object_id('tempdb.dbo.#deDup') is not null
   drop table #deDup

Select [incidentNumber],securityIncidentKey,
row_number() over (partition by [incidentNumber] order by securityIncidentKey DESC) as rowNumber
into #deDup
from dbo.securityIncidentDim where [incidentNumber] IN (
										Select [incidentNumber]
										from #baseTable
										group by [incidentNumber]
										having count(*) >1)
--Total Count : 1059
--Select count(*) from #deDup
--Distinct checkSum : 529
--Select distinct [workspaceId] from #deDup where rowNumber = 1
--DELETE a 
--To be Deleted Duplicate Record Count: 1059 - 529 =  530
Select count(*)
--DELETE a
from dbo.securityIncidentDim a
inner join #deDup b
on a.[incidentNumber] = b.[incidentNumber]
and a.securityIncidentKey = b.securityIncidentKey
where rowNumber <> 1