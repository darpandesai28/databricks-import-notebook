if object_id('tempdb.dbo.#baseTable') is not null
   drop table #baseTable
SELECT [service]
      ,[id]
      ,[status]
      ,[link]
      ,[issueId]
      ,[issueTitle]
      ,[issueImpactDescription]
      ,[issueClassification]
      ,[issueOrigin]
      ,[issueStatus]
      ,[issueService]
      ,[issueFeature]
      ,[issueFeatureGroup]
      ,[issueIsResolvedYN]
      ,[issueIsHighImpactYN]
      --,[issueDetails]
      --,[issuePosts]
      ,[issueStartDate]
      ,[issueStartDateTime]
      ,[issueEndDate]
      ,[issueEndDateTime]
      ,[issueLastModifiedDate]
      ,[issueLastModifiedDateTime]
      ,[filepath]
      ,[fileCreatedDate]
      ,[fileCreatedDateTime]
      ,[whoCreated]
      ,[whenCreated]
      ,[whoUpdated]
      ,[whenUpdated]
      ,[fromSource]
      ,[fromType]
      ,[checkSum]
  into #baseTable 
  FROM [a365].[serviceHealth]

--Select * from #baseTable

if object_id('tempdb.dbo.#deDup') is not null
   drop table #deDup
   
Select a.service,a.id,a.status,a.issueId,a.issueLastModifiedDateTime,a.fileCreatedDateTime,
row_number() over (partition by a.service,a.id,a.status,a.issueId order by a.issueLastModifiedDateTime desc,a.fileCreatedDateTime DESC) as rowNumber
into #deDup
from [a365].[serviceHealth] a
INNER JOIN (Select service, id, issueId, status
				   from #baseTable
				   group by service, id, issueId, status
				 having count(*) >1) b
	ON  a.service = b.service
	and a.id = b.id
	and a.issueId = b.issueId
	and a.status = b.status
	

--Total Count : 1059
--Select count(*) from #deDup
--Distinct checkSum : 529
--Select distinct [workspaceId] from #deDup where rowNumber = 1
--DELETE a 
--To be Deleted Duplicate Record Count: 1059 - 529 =  530

Select *
--DELETE a
from [a365].[serviceHealth] a
inner join #deDup b
ON  a.service = b.service
and a.id = b.id
and	a.issueId = b.issueId
and a.status = b.status
and a.issueLastModifiedDateTime = b.issueLastModifiedDateTime
and a.fileCreatedDateTime = b.fileCreatedDateTime
where rowNumber <> 1

--Select 2365 + 685 + 1687

/*
Select a.* from [a365].[serviceHealth] a
left outer join #deDup b
ON  a.service = b.service
and a.id = b.id
and	a.issueId = b.issueId
and a.status = b.status
and a.issueLastModifiedDateTime = b.issueLastModifiedDateTime
where b.id is null 
and b.issueId is null 
and b.service is null
and b.status is null
and b.issueLastModifiedDateTime is null
*/
