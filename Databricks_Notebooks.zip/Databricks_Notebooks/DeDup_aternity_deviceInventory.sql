if object_id('tempdb.dbo.#baseTable') is not null
   drop table #baseTable
Select * into #baseTable 
         from aternity.deviceInventory

--Select Top 10 * from #baseTable

if object_id('tempdb.dbo.#deDup') is not null
   drop table #deDup

Select [checkSum],deviceInventoryKey,
row_number() over (partition by [checkSum] order by deviceInventoryKey DESC) as rowNumber
into #deDup
from aternity.deviceInventory where [checkSum] IN (
										Select [checkSum]
										from #baseTable
										group by [checkSum]
										having count(*) >1)
--Total Count : 1059
--Select count(*) from #deDup
--Distinct checkSum : 529
--Select distinct [workspaceId] from #deDup where rowNumber = 1
--DELETE a 
--To be Deleted Duplicate Record Count: 1059 - 529 =  530
Select count(*)
--DELETE a
from aternity.deviceInventory a
inner join #deDup b
on a.[checkSum] = b.[checkSum]
and a.deviceInventoryKey = b.deviceInventoryKey
where rowNumber <> 1