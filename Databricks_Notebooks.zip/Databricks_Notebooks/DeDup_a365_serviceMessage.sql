if object_id('tempdb.dbo.#baseTable') is not null
   drop table #baseTable
SELECT [id]
      ,[title]
      ,[category]
      ,[severity]
      ,[viewPoint]
      ,[isMajorChangeYN]
      ,[hasAttachmentsYN]
      ,[tags]
      ,[services]
      ,[details]
      --,[body]
      ,[startDate]
      ,[startDateTime]
      ,[endDate]
      ,[endDateTime]
      ,[lastModifiedDate]
      ,[lastModifiedDateTime]
      ,[actionRequiredByDate]
      ,[actionRequiredByDateTime]
      ,[expiryDate]
      ,[expiryDateTime]
      ,[filepath]
      ,[fileCreatedDate]
      ,[fileCreatedDateTime]
      ,[whoCreated]
      ,[whenCreated]
      ,[whoUpdated]
      ,[whenUpdated]
      ,[fromSource]
      ,[fromType]
      ,[checkSum]
  into #baseTable 
  FROM [a365].[serviceMessage]

--Select * from #baseTable

if object_id('tempdb.dbo.#deDup') is not null
   drop table #deDup

Select a.id, a.services,a.lastModifiedDateTime,a.fileCreatedDateTime,
row_number() over (partition by a.id, a.services order by a.lastModifiedDateTime desc,a.fileCreatedDateTime DESC) as rowNumber
into #deDup
from [a365].[serviceMessage] a
INNER JOIN (Select id, services
				   from #baseTable
				   group by id, services
				 having count(*) >1) b
	ON  a.id = b.id
	and a.services = b.services

--Total Count : 1059
--Select count(*) from #deDup
--Distinct checkSum : 529
--Select distinct [workspaceId] from #deDup where rowNumber = 1
--DELETE a 
--To be Deleted Duplicate Record Count: 1059 - 529 =  530

Select *
--DELETE a
from [a365].[serviceMessage] a
inner join #deDup b
ON  a.id = b.id
and a.services = b.services
and a.LastModifiedDateTime = b.LastModifiedDateTime
and a.fileCreatedDateTime = b.fileCreatedDateTime
where rowNumber <> 1

--Select 985 + 464 + 728

/*
Select a.* from [a365].[serviceMessage] a
left outer join #deDup b
on a.id = b.id
and a.services = b.services
and a.LastModifiedDateTime = b.LastModifiedDateTime
where b.id is null 
and b.services is null 
and b.LastModifiedDateTime is null
*/
